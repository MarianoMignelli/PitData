
# PitData - Dashboard de Telemetría Automovilística

Este proyecto permite a pilotos o ingenieros cargar un archivo CSV de telemetría y visualizar datos clave:
- Velocidad vs Tiempo
- RPM vs Tiempo
- Fuerzas G (lateral y longitudinal)
- Comparación entre vueltas

## Cómo correrlo localmente

```bash
pip install -r requirements.txt
streamlit run main.py
```

## Cómo desplegarlo

Subilo a GitHub y usá [Streamlit Cloud](https://streamlit.io/cloud) para publicarlo.
